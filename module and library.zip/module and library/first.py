#first and second
print("module name of first: ", __name__)
def add (x,y):
    print(x+y)

if __name__== '__main__':
    add(3,7)
else:
    print("module name of first after import: ", __name__)
    print("First is imported")