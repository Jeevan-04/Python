import banking_module as abc
a={"ram":2000,"shyam":1250,"sita":150,"gita":3225}
b=int(input("1.Withdraw \n 2.Deposit \n 3.Check Balance"))
if b==1:
    c=abc.money
    c.withdraw(a)
elif b==2:
    d=abc.money
    d.deposit(a)
elif b==3:
    e=abc.money
    e.balance(a)
else:
    print("Invalid Input")