#withdraw, check balance, deposit.
x={}
class money:
    def deposit(x):
        a=input("Enter the name: ")
        if a in x:
            b=int(input("Amount to deposit: "))
            x[a]= b+(x[a])
            print("Balance: ",x[a])
        else:
            print("Account doesn't exist")
    def withdraw(x):
        c=input("Enter the name: ")
        if c in x:
            b=int(input("Amount to withdraw: "))
            if b<(x[c]):
                x[c]=(x[c])-b
                print("Balance: ",x[b])
            else:
                print("Insufficient Balance")
        else:
            print("Account doesn't exist")
    def balance(x):
        d=input("Enter the name: ")
        if d in x:
            print(x[d])
        else:
            print("Account doesn't exist")