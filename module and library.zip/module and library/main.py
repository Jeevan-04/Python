#my_module and main
import my_module #allies name import my_module as abc
# a=my_module.Addition() #a=abc.Addition()
# a.add(2,3)
b=my_module.Subtraction()
b.subtract(5,2)
from importlib import reload  # reload(my_module) old syntax
reload(my_module)




'''from my_module import Addition
a=Addition()
a.add(2,3)'''

