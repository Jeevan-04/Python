#my_module and main
class Subtraction:
    def subtract(self,x,y):
        self.x=x
        self.y=y
        print(self.x-self.y)

if __name__ == '__main__':
    print("Executed directly")
    class Addition:
        def add(self,x,y):
            self.x=x
            self.y=y
            print(self.x+self.y)
else:
    print("Executed after import")